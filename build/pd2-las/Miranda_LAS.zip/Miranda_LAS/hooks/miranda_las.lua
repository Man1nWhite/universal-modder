LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.miranda = {
	category = "miranda",

	unit = "units/miranda/skins/miranda/miranda",
	fps_unit = "units/miranda/skins/miranda/fps_miranda",

	hide_mask = true,
	hide_armor = true,
	replace_all = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
