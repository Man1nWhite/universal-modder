Pick one or the other - not both!
Put "Hoxier Hoxton Burnt" or "Hoxier Hoxton No Burns" in your
PAYDAY 2/assets/mod_overrides folder.

If you want Hox's mask to match his magically healed face, you can use "Hox's
Mask No Burns" as well.

If you had version one, make sure you delete "Hoxier Hoxton" in mod_overrides
before you put "Hoxier Hoxton Burnt" or "Hoxier Hoxton No Burns" in.