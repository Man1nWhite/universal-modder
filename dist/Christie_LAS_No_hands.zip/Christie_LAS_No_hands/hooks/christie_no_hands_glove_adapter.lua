-- Christie_LAS_No_hands LAS: vanilla-suit glove behaviour for las_christie_no_hands.
-- This outfit ships NO hands (cut at the wrist), so the heister's own gloves
-- must spawn: LAS forces default_glove_id = false (no hands at all) and
-- disables the glove adapter. Restore a real default glove, re-enable the
-- adapter, and keep the stock hands visible as fallback.
-- See las_outfit_pack.render_glove_adapter_lua for the full rationale.
Hooks:PostHook(BlackMarketTweakData, "init", "christie_no_hands_GloveAdapter", function(self)
	local ps = self.player_styles and self.player_styles["las_christie_no_hands"]
	if not ps then return end

	-- A real default glove, exactly like the vanilla/DLC suits (LAS's
	-- fresh-table read drops this, leaving "Default" gloves with no unit).
	ps.default_glove_id = "heist_default"

	-- Enable the adapter with a table (NOT a boolean: BeardLib's table.merge
	-- would call pairs(true)). An empty table keeps the default hnd_forearms.
	ps.glove_adapter = {}

	-- Drop the exclude-list entry LAS added for replace_body.
	local list = self.glove_adapter and self.glove_adapter.player_style_exclude_list
	if list then
		for i = #list, 1, -1 do
			if list[i] == "las_christie_no_hands" then table.remove(list, i) end
		end
	end

	-- Keep the stock hands visible as a guaranteed fallback.
	if ps.body_replacement then ps.body_replacement.hands = false end
	if ps.third_body_replacement then ps.third_body_replacement.hands = false end
end)
