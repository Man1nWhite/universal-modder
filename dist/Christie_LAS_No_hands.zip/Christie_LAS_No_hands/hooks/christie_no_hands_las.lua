LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.christie_no_hands = {
	category = "christie_no_hands",

	unit = "units/christie_no_hands/skins/christie_no_hands/christie_no_hands",
	fps_unit = "units/christie_no_hands/skins/christie_no_hands/fps_christie_no_hands",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
