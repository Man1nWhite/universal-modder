LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.christie_slim = {
	category = "christie_slim",

	unit = "units/christie_slim/skins/christie_slim/christie_slim",
	fps_unit = "units/christie_slim/skins/christie_slim/fps_christie_slim",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
