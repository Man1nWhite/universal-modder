Geralt VO over Rust Stream

WHAT IT IS
Rust (npc_criminal_wild_1), the punk heister's heister voice lines, replaced by short Geralt of Rivia barks: this pack writes
315 files into soundbanks/streamed/regular_vox/ under the shared voice-line ids. The game plays
a line by its id, so the clip answers that line whether it comes from a bark event, a heist script
or a teammate callout - no event table to keep up to date.

Whether Rust plays his heister barks from the shared regular_vox bank is NOT verified: the original crew do; the install doc notes newer heisters are documented elsewhere as char_<heister>. If Rust still barks in his vanilla voice in game, that is why, and this pack cannot cover him without a dedicated-bank variant.

THIS IS ONE OF SEVERAL VOICE PACKS
Regular_vox voice-line ids are shared between heisters, and this pack writes the same ids as
Miranda_Lawson_VO_over_Hila_Stream.zip (and any other pack built from them). INSTALL ONLY ONE:
another pack writing the same ids wins or loses by load order, and with two installed you get a
blend, not two voices.

REQUIRES
A working copy of PAYDAY 2 with SuperBLT (or any BLT build). Nothing else:
this route is a file replacement, so BeardLib and the XAudio API are not used.

INSTALL
  1. Close PAYDAY 2.
  2. Copy the whole folder "Geralt VO over Rust Stream" into
       ...\\Steam\\steamapps\\common\\PAYDAY 2\\mods\\
     Final check: PAYDAY 2\\mods\\Geralt VO over Rust Stream\\main.xml must exist.
     Do not nest it twice (mods\\Geralt VO over Rust Stream\\Geralt VO over Rust Stream\\main.xml is wrong).
  3. Start the game and play a heist. The barks you recorded should be Geralt of Rivia's; the
     heist-scripted story lines he speaks as an NPC are not touched - those are not heister voice
     lines. The clips' wording has not been verified by ear.

UNINSTALL
Delete this folder, or untick it in the main-menu Mods list.

HOW IT REPLACES LINES
Every heister voice line is soundbanks/streamed/regular_vox/<id>.stream - RIFF IMA ADPCM, 44.1 kHz
mono, 64 samples per 36-byte block. Replacing the file under that id replaces the line, which is how
voice packs have always been made. The clips are cut from the source MP3s and encoded to ADPCM
(measured 30 dB SNR against the sources, i.e. transparent for speech at this bitrate).

WHAT IS NOT IN HERE
  * 27 of the 885 ids in the shared table are streamed by the vanilla game as Wwise Vorbis,
    and only the Wwise encoder can write that. Those ids are left out on purpose.
  * 49 slots (546 ids) have no take in references/GERALT VOICE (PAYDAY 2).zip: vanilla audio plays
    there. Everything else on the regular_vox bank (Dallas, Hoxton, Wolf, chained out, Hila, ...) is replaced too; the bank is shared.
  * The `robbers_mission_gen` bank: those ids are heist-scripted NPC lines with their own text.

IF NOTHING CHANGES
Check that the folder is in mods/ and not nested, that you are playing a heister on the shared
regular_vox bank (Rust (npc_criminal_wild_1), the punk heister), that no other pack writes the same ids (see above), and the
in-game log lines named in docs/pd2-las/in-game-checklist.md.

CONTENTS
  main.xml                              mod folder marker, nothing to configure
  mod.txt                               BLT mod-list metadata
  soundbanks/streamed/regular_vox/      315 .stream files, 584s of audio in all
  geralt_rust_stream_map.csv               id -> slot -> source take (build manifest)

Source archives: references/GERALT VOICE (PAYDAY 2).zip
Mapping: voice_lines_vox/miranda_lawson/hila_intent_cuts.csv
Nothing outside this folder is touched: music, radio, other heisters and all vanilla files stay as
they are, except for the shared-bank caveat above.
