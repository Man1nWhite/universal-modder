-- Geralt VO over Rust: BeardLib 5.2.0 <Sounds> lifecycle fix.
--
-- Fixes three bugs that leave BeardLib <Sounds> silent in PAYDAY 2 heists:
--   1. Modern SuperBLT (mods/base/base.lua) defines _G.XAudio = {} before
--      blt.xaudio.setup() runs, so SoundsModule:init()'s `if not XAudio` check
--      skips OpenAL initialization and blt.xaudio.issetup() remains false.
--   2. On older SuperBLT builds where _G.XAudio is nil until setup(), BeardLib's
--      Core.lua constructs BeardLibSoundManager with self.Closed = true and
--      skips MixedSoundSource.lua (`if not XAudio then return end`) before
--      SoundsModule runs.
--   3. Hooks/GeneralHooks.lua hooks Setup:unload_packages -> Sound:Close(),
--      wiping self.buffers = {} and setting self.Closed = true across state
--      transitions, while Sound:Open() returns early when self.Closed is true.

local function ensure_xaudio()
	if blt and blt.xaudio and blt.xaudio.setup then
		if not blt.xaudio.issetup or not blt.xaudio.issetup() then
			blt.xaudio.setup()
		end
	end
	return XAudio ~= nil
end

local function ensure_mixed_sound_source()
	if not XAudio then
		return false
	end
	if not MixedSoundSource and BeardLib and BeardLib.ModPath then
		local base = BeardLib.ModPath
		local mss_path = (Path and Path.Combine and Path:Combine(base, "Classes/MixedSoundSource.lua"))
			or (base .. "Classes/MixedSoundSource.lua")
		local exists = (FileIO and FileIO.Exists and FileIO:Exists(mss_path))
			or (SystemFS and SystemFS.exists and SystemFS:exists(mss_path))
		if exists then
			dofile(mss_path)
		end
	end
	if MixedSoundSource and not MixedSoundSource._um_stop_patched then
		MixedSoundSource._um_stop_patched = true
		local orig_init = MixedSoundSource.init
		function MixedSoundSource:init(sound_id, queue, engine_source, clbk, cookie)
			orig_init(self, sound_id, queue, engine_source, clbk, cookie)
			if engine_source then
				if engine_source.is_relative and engine_source:is_relative() then
					self:set_relative(true)
				elseif engine_source.get_position then
					local pos = engine_source:get_position()
					if pos then
						self:set_position(pos)
					end
				end
			end
		end
		function MixedSoundSource:stop()
			self._queue = {}
			if not self:is_closed() then
				MixedSoundSource.super.stop(self)
				self:close()
			end
		end
	end
	return MixedSoundSource ~= nil
end

local function spec_key(data)
	return table.concat({
		tostring(data.id or ""),
		tostring(data.prefix or ""),
		tostring(data.prefixes_strict and "1" or "0"),
		tostring(data.full_path or ""),
	}, "\0")
end

local function apply_beardlib_sound_fix()
	if not BeardLib or not BeardLib.Managers or not BeardLib.Managers.Sound then
		return
	end
	local sm = BeardLib.Managers.Sound
	local has_xaudio = ensure_xaudio()
	ensure_mixed_sound_source()
	if has_xaudio then
		sm.Closed = false
	end

	if sm._um_sound_fix_v1 then
		return
	end
	sm._um_sound_fix_v1 = true
	sm._um_persistent_map = sm._um_persistent_map or {}
	sm._um_persistent_list = sm._um_persistent_list or {}

	local orig_add_buffer = sm.AddBuffer
	function sm:AddBuffer(data, force)
		if ensure_xaudio() then
			ensure_mixed_sound_source()
			self.Closed = false
		end
		if type(data) == "table" and data.full_path and not data.unload then
			local k = spec_key(data)
			if data.close_previous then
				for i = #self._um_persistent_list, 1, -1 do
					local prev = self._um_persistent_list[i]
					if prev.id == data.id and self:ComparePrefixes(prev, data.id, data.prefixes) then
						self._um_persistent_map[spec_key(prev)] = nil
						table.remove(self._um_persistent_list, i)
					end
				end
			end
			if not self._um_persistent_map[k] then
				self._um_persistent_map[k] = data
				table.insert(self._um_persistent_list, data)
			else
				self._um_persistent_map[k] = data
			end
		end
		return orig_add_buffer(self, data, force)
	end

	local orig_open = sm.Open
	function sm:Open()
		if ensure_xaudio() then
			ensure_mixed_sound_source()
			self.Closed = false
			for _, spec in ipairs(self._um_persistent_list) do
				if not self:GetLoadedBuffer(spec.id, spec.prefixes, true) then
					if not spec.load_on_play then
						local buffer = XAudio.Buffer:new(spec.full_path)
						buffer.data = spec
						table.insert(self.buffers, buffer)
					else
						table.insert(self.buffers, spec)
					end
					if not self:GetSound(spec.id, spec.prefixes) then
						self:AddSoundID(spec)
					end
				end
			end
			if SoundDevice then
				for _, redirect in ipairs(self.redirects) do
					if redirect.id then
						self:StoreFloat(redirect.id)
					end
				end
			end
		end
		return orig_open(self)
	end
end

apply_beardlib_sound_fix()
