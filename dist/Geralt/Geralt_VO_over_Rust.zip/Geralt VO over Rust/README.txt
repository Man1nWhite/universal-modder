Geralt VO over Rust — PAYDAY 2 Voice Pack
=================================

Replaces Rust's (`rb16`) combat barks and squad summon callouts with Geralt of Rivia's
voice while leaving uncovered Rust lines as vanilla Rust audio.

Prerequisites
-------------
  - SuperBLT (provides the `blt.xaudio` OpenAL API)
  - BeardLib 5.x (provides `<Sounds>` event redirection on `prefix="rb16"`)

Install (pick ONE folder — do not install in both at once)
----------------------------------------------------------
  1. Recommended (matches `Geralt over Rust` and `Marine VO for Rust`):
       Extract `Geralt VO over Rust` into `PAYDAY 2/assets/mod_overrides/` so that
       `PAYDAY 2/assets/mod_overrides/Geralt VO over Rust/main.xml` exists.
     (Alternative: extract `Geralt VO over Rust` into `PAYDAY 2/mods/` so that
      `PAYDAY 2/mods/Geralt VO over Rust/main.xml` exists.)
  2. Start PAYDAY 2 and play a heist as Rust (or with Rust as an AI / co-op teammate).

What is covered (36 clips across 29 bark slots + 2 teammate callouts = 45 events)
-------------------------------------------------------------------------------------------------------------
  - 29 combat/stealth bark slots mapped to Rust (`prefix="rb16"`), including `<random>`
    multi-take rotation on:
      * `civ.down` (4 takes)
      * `inspire.faster` (2 takes)
      * `mask.go` (2 takes)
  - 2 character-specific teammate summon shouts (`PlayerStandard` `come` shout):
      * `f21ab_sin` — Geralt calls Hila ("Hila.")
      * `f21d_sin`  — Geralt calls Old Hoxton ("Hoxton.")
  - Uncovered Rust lines (heist-specific mission chatter, pagers, etc.) remain vanilla Rust.
  - Other heisters (Hila `rb21`, Old Hoxton `rb5`, Dallas `rb4`, etc.) are untouched even
    when posting the same bark event names.

Why `hooks/beardlib_sound_fix.lua` is included
----------------------------------------------
BeardLib 5.2.0's `<Sounds>` module has three lifecycle bugs with modern SuperBLT:
  1. SuperBLT pre-defines `_G.XAudio = {}` before `blt.xaudio.setup()` runs, causing
     `SoundsModule:init()` (`if not XAudio`) to skip OpenAL initialization.
  2. If `XAudio` was nil when `Core.lua` ran, `BeardLibSoundManager.Closed` starts `true`
     and `MixedSoundSource` is skipped.
  3. `Setup:unload_packages` calls `BeardLib.Managers.Sound:Close()`, wiping `self.buffers`
     and leaving `self.Closed = true` when entering a heist.
`hooks/beardlib_sound_fix.lua` fixes all three idempotently without modifying BeardLib on disk.

Uninstall
---------
Delete `Geralt VO over Rust` from `assets/mod_overrides/` (or `mods/`).
