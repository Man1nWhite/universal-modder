-- Christie_Clover_LAS LAS: vanilla-suit glove behaviour for las_clover_christie.
-- This outfit ships NO hands (cut at the wrist), so the heister's own gloves
-- must spawn: LAS forces default_glove_id = false (no hands at all) and
-- disables the glove adapter. Restore a real default glove, re-enable the
-- adapter, and keep the stock hands visible as fallback.
-- See las_outfit_pack.render_glove_adapter_lua for the full rationale.
Hooks:PostHook(BlackMarketTweakData, "init", "clover_christie_GloveAdapter", function(self)
	local ps = self.player_styles and self.player_styles["las_clover_christie"]
	if not ps then return end

	local function restore_gloves(style)
		if not style then return end

		-- A real default glove, exactly like the vanilla/DLC suits (LAS's
		-- fresh-table read drops this, leaving "Default" gloves with no unit).
		style.default_glove_id = "heist_default"

		-- Enable the adapter with a table (NOT a boolean: BeardLib's table.merge
		-- would call pairs(true)). An empty table keeps the default hnd_forearms.
		style.glove_adapter = {}

		-- Keep stock hands visible as a guaranteed fallback.
		if style.body_replacement then style.body_replacement.hands = false end
		if style.third_body_replacement then style.third_body_replacement.hands = false end
	end

	-- LAS remaps every character_override independently, so character-specific
	-- values take precedence over the style-level values in get_player_style_value.
	restore_gloves(ps)
	for _, character in pairs(ps.characters or {}) do
		restore_gloves(character)
	end

	-- LAS inserts once for the style and again for each replace_body character.
	-- Walk backwards so every copy is removed without skipping adjacent entries.
	local list = self.glove_adapter and self.glove_adapter.player_style_exclude_list
	if list then
		for i = #list, 1, -1 do
			if list[i] == "las_clover_christie" then table.remove(list, i) end
		end
	end
end)
