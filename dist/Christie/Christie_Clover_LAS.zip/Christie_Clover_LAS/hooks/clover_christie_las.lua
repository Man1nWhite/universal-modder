LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.clover_christie = {
	category = "clover_christie",

	unit = "units/clover_christie/skins/clover_christie/clover_christie",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
