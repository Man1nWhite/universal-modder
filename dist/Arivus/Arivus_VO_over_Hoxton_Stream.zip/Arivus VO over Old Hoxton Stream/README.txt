Arivus VO over Old Hoxton Stream

WHAT IT IS
Old Hoxton (npc_criminals_suit_1, mtr_old_hoxton), the shared-suit heister's heister voice lines, replaced by short Arivus barks: this pack writes
324 files into soundbanks/streamed/regular_vox/ under the shared voice-line ids. The game plays
a line by its id, so the clip answers that line whether it comes from a bark event, a heist script
or a teammate callout - no event table to keep up to date.

Old Hoxton's heister lines are the shared regular_vox ones, like every heister on that bank - installing this pack replaces those lines for Dallas, Hoxton, Hila and everyone else on the bank, not only for Old Hoxton.

THIS IS ONE OF SEVERAL VOICE PACKS
Regular_vox voice-line ids are shared between heisters, and this pack writes the same ids as
Miranda_Lawson_VO_over_Hila_Stream.zip (and any other pack built from them). INSTALL ONLY ONE:
another pack writing the same ids wins or loses by load order, and with two installed you get a
blend, not two voices.

REQUIRES
A working copy of PAYDAY 2 with SuperBLT (or any BLT build). Nothing else:
this route is a file replacement, so BeardLib and the XAudio API are not used.

INSTALL
  1. Close PAYDAY 2.
  2. Copy the whole folder "Arivus VO over Old Hoxton Stream" into
       ...\\Steam\\steamapps\\common\\PAYDAY 2\\mods\\
     Final check: PAYDAY 2\\mods\\Arivus VO over Old Hoxton Stream\\main.xml must exist.
     Do not nest it twice (mods\\Arivus VO over Old Hoxton Stream\\Arivus VO over Old Hoxton Stream\\main.xml is wrong).
  3. Start the game and play a heist. The barks you recorded should be Arivus's; the
     heist-scripted story lines he speaks as an NPC are not touched - those are not heister voice
     lines. The clips' wording has not been verified by ear.

UNINSTALL
Delete this folder, or untick it in the main-menu Mods list.

HOW IT REPLACES LINES
Every heister voice line is soundbanks/streamed/regular_vox/<id>.stream - RIFF IMA ADPCM, 44.1 kHz
mono, 64 samples per 36-byte block. Replacing the file under that id replaces the line, which is how
voice packs have always been made. The clips are cut from the source MP3s and encoded to ADPCM
(measured 30 dB SNR against the sources, i.e. transparent for speech at this bitrate).

WHAT IS NOT IN HERE
  * 27 of the 885 ids in the shared table are streamed by the vanilla game as Wwise Vorbis,
    and only the Wwise encoder can write that. Those ids are left out on purpose.
  * 59 slots (540 ids) have no take in references/ARIVUS VOICE (PAYDAY 2).zip: vanilla audio plays
    there. The one borrowed file (call_teammate.hey_you, 'Hoxton.') is a Geralt take.
  * The `robbers_mission_gen` bank: those ids are heist-scripted NPC lines with their own text.

IF NOTHING CHANGES
Check that the folder is in mods/ and not nested, that you are playing a heister on the shared
regular_vox bank (Old Hoxton (npc_criminals_suit_1, mtr_old_hoxton), the shared-suit heister), that no other pack writes the same ids (see above), and the
in-game log lines named in docs/pd2-las/in-game-checklist.md.

CONTENTS
  main.xml                              mod folder marker, nothing to configure
  mod.txt                               BLT mod-list metadata
  soundbanks/streamed/regular_vox/      324 .stream files, 442s of audio in all
  arivus_hoxton_stream_map.csv               id -> slot -> source take (build manifest)

Source archives: references/ARIVUS VOICE (PAYDAY 2).zip
Mapping: voice_lines_vox/miranda_lawson/hila_intent_cuts.csv
Nothing outside this folder is touched: music, radio, other heisters and all vanilla files stay as
they are, except for the shared-bank caveat above.
