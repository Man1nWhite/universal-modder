Arivus head over Old Hoxton — glTF / DDS interchange export

Contents: arivus_head_over_old_hoxton.glb (the g_head_old_hoxton drawable of
npc_criminals_suit_1.model, bind-pose skin, alpha-masked hair) and the five
DDS textures of the Arivus_over_Hoxton pack. The GLB embeds PNG copies of the
two textures its material uses; the .dds files are the pack's raw .texture
bytes, renamed by extension only.

This is not a PAYDAY 2 mod to install. It is a viewer/interchange export for
Blender, three.js or a phone: runtime_verified is false, the exporter is not a
runtime oracle, and the source pack's own bytes are untouched.

Rebuild from the repository root with `make -sC tools/pd2-las glb`. The output
is byte-reproducible in the pinned environment; `make -sC tools/pd2-las fresh`
proves it. Provenance and per-file digests: manifest.json.
