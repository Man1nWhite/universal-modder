Lawson - Legendary Armour Skins outfit pack
============================================

Makes the Lawson model wearable as an armor/outfit skin (the same
system as ModWorkShop 'Wardrobe Mod' / Legendary Armour Skins packs
such as 'Yorha No. 2 Type B (2B) [LAS]').

Requirements
- SuperBLT
- BeardLib
- Legendary Armour Skins (Wardrobe Mod) by Cpone
  https://modworkshop.net/mod/24006

Install
1. Install the requirements above.
2. Extract this ZIP into PAYDAY 2\assets\mod_overrides\ so that the
   final layout is:
     PAYDAY 2\assets\mod_overrides\Lawson_LAS\main.xml
     PAYDAY 2\assets\mod_overrides\Lawson_LAS\assets\...
3. Restart the game, open Customize Armor (armor skin menu) and
   equip 'Lawson'.

Notes
- Replaces body, head, hands, arms and vest in both third and first
  person; the heister mask slot is taken by the skin's head.
- First-person arms are cut from the rigged body (shoulders to
  fingers) and skin to the standard heister FPS skeleton.
- Not verified in-game at packaging time; test offline first.

Remove
With the game closed, move Lawson_LAS out of assets\mod_overrides\.
