Miranda Lawson — Legendary Armour Skins add-on (1.1.0-rc1, experimental)
=======================================================================

Requires PAYDAY 2 on PC, SuperBLT, BeardLib and Legendary Armour Skins /
Wardrobe Mod (ModWorkShop #24006). Loaders/frameworks are NOT bundled.
LAS contract inspected against 4.1.9; your installed version is not known.
This is an actual LegendaryArmours registration, not a plain PlayerStyle
with LAS branding. LAS 4.x exposes it as [LAS] Miranda Lawson in the native
Outfit / Player Styles selector (internal id: las_lawson). Older LAS
versions may use their armor-skin menu. The no-LAS BeardLib edition remains
separate and uses a different item/resource namespace.

Install / upgrade (manual, game closed)
--------------------------------------
1. Back up your save/profile and mod_overrides folder. If possible, select a
   vanilla outfit before upgrading/removing an equipped custom outfit.
2. Move the OLD Lawson_LAS folder completely OUT of assets/mod_overrides.
   Do not merely rename it within mod_overrides: BeardLib may still load it.
   Do not overlay this ZIP onto the old folder or keep two copies enabled.
3. Extract to PAYDAY 2/assets/mod_overrides/ so the exact layout is:
   PAYDAY 2/assets/mod_overrides/Lawson_LAS/main.xml
   PAYDAY 2/assets/mod_overrides/Lawson_LAS/hooks/register_lawson.lua
4. Restart the game completely. Choose [LAS] Miranda Lawson in Outfits on
   LAS 4.x, with Default gloves. Do not select the obsolete plain 'lawson'
   style from the previous, mislabeled package. For the first test, disable
   other character replacements and the separate BeardLib Lawson edition.
5. Start with the menu preview only. If it crashes, stop and retain fresh
   crash.txt, crashlog.txt and the SuperBLT/BeardLib logs; record the exact
   game, BeardLib and LAS versions. Do not repeat the same crash three times.
   Only if the preview works, continue with a backed-up OFFLINE heist.

What changed
------------
- LAS owns registration, body replacement and hide_mask behavior, as in the
  supplied 2B example. No copied framework code or global visual patches.
- Only outfit drawables remain (TPP: 7, FPS: 2); unused character/collision/
  vest/bag/hair-variant drawable chains and their materials are pruned.
- Every remaining model material is defined, including shadow_caster.
- Real g_body culling geometry with conservative bounds; no empty co_box.
- FPS arm selection uses one immutable adjacency ring, not a face-order flood.
- Standard JSON localization, two menu-icon paths, deterministic/atomic ZIP,
  and source/payload hashes in BUILD_INFO.json.

Limits — NOT a verified game fix
-------------------------------
The original Lawson_LAS was reported to crash during menu unit spawning.
The rebuilt package addresses reproducible resource/registration defects;
no PAYDAY 2 runtime is available here to verify that the crash is gone.
It reuses the supplied Clover-rigged mesh, which the user reports is badly
broken visually. No re-rig, UV seam repair or weapon/hand alignment fix has
been performed. Do not mistake passing offline tests for good rendering.
Mask hiding depends on LAS and is unverified on your installed versions.
VR, other appearance mods, multiplayer and unmodded peers are untested.
This is a private derivative with unresolved asset redistribution rights;
see CREDITS.txt. The unrelated 2B model/textures are not included.

Rollback
--------
Equip a vanilla outfit if possible, close the game, and move only Lawson_LAS
out of assets/mod_overrides. Restore your backup if needed. Do not remove
shared loaders or delete saves. Keep the known-crashing old pack disabled.

Rebuild from repository root:
python tools/pd2-port/build_outfit.py
Output: dist/lawson_outfit.zip (root: Lawson_LAS)
