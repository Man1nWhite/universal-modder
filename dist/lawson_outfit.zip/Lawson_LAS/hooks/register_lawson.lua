-- Lawson LAS add-on. Requires Legendary Armour Skins / Wardrobe Mod.
-- The framework owns loading, mask hiding and character-visual hooks.
LegendaryArmours = LegendaryArmours or {}
LegendaryArmours.lawson = {
    category = "lawson_las",
    name_id = "bm_askn_lawson",
    desc_id = "bm_askn_lawson_desc",
    unit = "units/wardrobe_mod/armor_skins/lawson/lawson",
    fps_unit = "units/wardrobe_mod/armor_skins/lawson_fps/lawson_fps",
    hide_mask = true,
    hide_armor = true,
    replace_all = true,
    fps_hide_armor = true,
    fps_replace_body = true
}
