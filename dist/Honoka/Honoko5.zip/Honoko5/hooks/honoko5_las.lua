LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.honoko5 = {
	category = "honoko5",

	unit = "units/honoko5/skins/honoko5/honoko5",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
