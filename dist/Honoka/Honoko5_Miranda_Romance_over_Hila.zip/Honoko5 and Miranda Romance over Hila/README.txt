Honoko5 + Miranda Romance over Hila

Extract the 'Honoko5 and Miranda Romance over Hila' folder into PAYDAY 2/assets/mod_overrides/.
Remove other Hila body/head overrides first, including the standalone Miranda over Hila mods.
Select Hila and her default outfit. Neither donor ZIP, LAS, SuperBLT nor BeardLib is required.

This replaces Hila's default third-person body and head in heists and the menu/lobby.
Hila's hands, first-person arms, equipment, mask and armor behavior are not replaced.
Alternate outfits/armor mods can hide or clip through the replacement. The build has been
checked offline, not in the running game. Remove this folder to uninstall.
