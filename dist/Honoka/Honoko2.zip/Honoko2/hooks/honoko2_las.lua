LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.honoko2 = {
	category = "honoko2",

	unit = "units/honoko2/skins/honoko2/honoko2",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
