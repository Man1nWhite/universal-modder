-- OfficeSuite LAS: the outfit's own modelled hands, never a default glove.
-- D58. "Default" gloves must resolve to no glove unit, so the hands this pack
-- models are the ones that show. A glove the player picks by hand still spawns
-- and wins. See las_outfit_pack.render_own_hands_lua for the full rationale.
Hooks:PostHook(BlackMarketTweakData, "init", "officesuite_OwnHands", function(self)
	local ps = self.player_styles and self.player_styles["las_officesuite"]
	if not ps then return end

	-- No glove unit for "Default". BeardLib reads this value, and `false`
	-- means "spawn nothing"; the modelled hands stay.
	ps.default_glove_id = false

	-- The body still replaces the stock hands. This is what makes the modelled
	-- hands the only ones: with the stock hands visible there would be doubles.
	if ps.third_body_replacement then ps.third_body_replacement.hands = true end
	if ps.body_replacement then ps.body_replacement.hands = true end
end)
