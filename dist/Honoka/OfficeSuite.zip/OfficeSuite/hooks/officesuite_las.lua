LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.officesuite = {
	category = "officesuite",

	unit = "units/officesuite/skins/officesuite/officesuite",
	fps_unit = "units/officesuite/skins/officesuite/fps_officesuite",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
