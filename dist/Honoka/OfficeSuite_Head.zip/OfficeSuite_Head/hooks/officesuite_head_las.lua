LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.officesuite_head = {
	category = "officesuite_head",

	unit = "units/officesuite_head/skins/officesuite_head/officesuite_head",
	fps_unit = "units/officesuite_head/skins/officesuite_head/fps_officesuite_head",

	hide_mask = true,
	hide_armor = true,
	replace_all = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
