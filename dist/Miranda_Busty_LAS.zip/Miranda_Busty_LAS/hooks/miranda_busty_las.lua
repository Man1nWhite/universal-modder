LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.miranda_busty = {
	category = "miranda_busty",

	unit = "units/miranda_busty/skins/miranda_busty/miranda_busty",
	fps_unit = "units/miranda_busty/skins/miranda_busty/fps_miranda_busty",

	hide_mask = true,
	hide_armor = true,
	replace_all = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
