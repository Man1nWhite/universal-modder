LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.honoka = {
	category = "honoka",

	unit = "units/honoka/skins/honoka/honoka",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
