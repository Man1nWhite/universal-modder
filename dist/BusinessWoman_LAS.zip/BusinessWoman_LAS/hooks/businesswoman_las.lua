LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.businesswoman = {
	category = "businesswoman",

	unit = "units/businesswoman/skins/businesswoman/businesswoman",
	fps_unit = "units/businesswoman/skins/businesswoman/fps_businesswoman",

	hide_mask = true,
	hide_armor = true,
	replace_all = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
