-- BusinessWoman LAS: vanilla-suit glove behaviour for las_businesswoman.
-- Restores a real default glove (LAS forces default_glove_id = false, which
-- leaves "Default" gloves with no hands) and re-enables the glove adapter.
-- See bw_pack.render_glove_adapter_lua for the full rationale.
Hooks:PostHook(BlackMarketTweakData, "init", "BusinessWoman_GloveAdapter", function(self)
	local ps = self.player_styles and self.player_styles["las_businesswoman"]
	if not ps then return end

	-- The base game keeps a suit's hands visible by giving the style a REAL
	-- default glove (suit_default_gloves -> default_glove_id), so "Default"
	-- gloves resolve to an actual hand mesh. LAS sets default_glove_id = false,
	-- so "Default" gloves spawn nothing and the suit has no hands. Restore a
	-- real default glove, exactly like the vanilla/DLC suits.
	ps.default_glove_id = "heist_default"

	-- Enable the adapter with a table (NOT a boolean: BeardLib's table.merge
	-- would call pairs(true)). An empty table keeps the default hnd_forearms.
	ps.glove_adapter = {}

	-- Drop the exclude-list entry LAS added for replace_body.
	local list = self.glove_adapter and self.glove_adapter.player_style_exclude_list
	if list then
		for i = #list, 1, -1 do
			if list[i] == "las_businesswoman" then table.remove(list, i) end
		end
	end

	-- Do NOT hide the stock hands. LAS forces default_glove_id = false and the
	-- glove spawn above is not reliable in-game; the old approach hid the stock
	-- hands (body_replacement.hands = true) and relied solely on the glove unit,
	-- so when it failed to appear the suit had NO hands. Keeping hands = false
	-- lets the heister's own stock hands show through the sleeves as a guaranteed
	-- fallback (nothing is authored). When a glove unit DOES spawn (default or
	-- equipped) it sets var_hands_replace = 1 and replaces the stock hands, so
	-- there are no double hands.
	if ps.body_replacement then ps.body_replacement.hands = false end
	if ps.third_body_replacement then ps.third_body_replacement.hands = false end
end)
