-- BusinessWoman LAS: keep the heister's own gloves changeable.
-- Re-enables the vanilla glove adapter that LAS forces off for las_businesswoman.
-- See bw_pack.render_glove_adapter_lua for the full rationale.
Hooks:PostHook(BlackMarketTweakData, "init", "BusinessWoman_GloveAdapter", function(self)
	local ps = self.player_styles and self.player_styles["las_businesswoman"]
	if not ps then return end

	-- Enable the adapter with a table (NOT a boolean: BeardLib's table.merge
	-- would call pairs(true)). An empty table keeps the default hnd_forearms.
	ps.glove_adapter = {}

	-- Drop the exclude-list entry LAS added for replace_body.
	local list = self.glove_adapter and self.glove_adapter.player_style_exclude_list
	if list then
		for i = #list, 1, -1 do
			if list[i] == "las_businesswoman" then table.remove(list, i) end
		end
	end

	-- The outfit ships no hands: let the heister's hands/gloves show.
	if ps.body_replacement then ps.body_replacement.hands = false end
	if ps.third_body_replacement then ps.third_body_replacement.hands = false end
end)
