Miranda Lawson Outfit — BeardLib-native edition (experimental)
==============================================================

Requirements: PAYDAY 2 on PC, SuperBLT, and BeardLib with PlayerStyle support
(API checked against BeardLib 5.2.0). Legendary Armour Skins / Wardrobe Mod is
NOT required. This is a native outfit/player style, not an armor-skin texture.

Installation (manual; game closed)
---------------------------------
1. Back up the existing mod_overrides folder and your save/profile first.
2. Extract this ZIP into PAYDAY 2/assets/mod_overrides/.
   The resulting path must be:
   PAYDAY 2/assets/mod_overrides/Lawson_Outfit_BeardLib/main.xml
   Do not put it in mods/mod_overrides or add another enclosing ZIP-name folder.
3. Launch the game and open the Outfit / Player Styles list in Inventory.
   Select "Miranda Lawson (BeardLib)". For the supplied hands, use Default gloves.
4. First test in the inventory and an OFFLINE heist, including movement, weapon
   switching/reload, mask-on, outfit switching and several heisters/armors.

What is included
----------------
- Independent lawson_beardlib style ID, icons and resources. No vanilla heister
  asset paths are overridden; the old Lawson packs need not be installed.
- Third-person body/head/hair/hands/shadow and a separate first-person arm mesh.
- Both native first- and third-person body replacement maps. No runtime Lua
  hooks, LAS registration, updater, downloads, save edits or gameplay changes.
- Complete material coverage including shadow_caster; alpha-derived hair/lash
  opacity maps; a triangle-order-independent one-ring arm selection.

Important limits
----------------
- Structurally tested, NOT tested in PAYDAY 2. Rig, UV seams, hand/weapon alignment,
  culling, materials, VR, armor clipping and animations still need visual checks.
- This reuses the supplied Clover-rigged Lawson mesh. It is NOT a fresh rig or
  proof of an exact visual/behavioral match to the supplied 2B reference.
- Native PlayerStyle body replacement does NOT hide the separate equipped mask.
  Mask clipping is possible; there is deliberately no global mask-hiding hook.
- Non-default gloves may replace/overlap the supplied hands. Choose Default.
- Global unit fallback is configured for every heister, but individual skeletons
  and body proportions are unverified. VR and online synchronization are untested.
- Unique IDs avoid the old outfit's registration collision; simultaneous legacy
  character replacements or other appearance mods can still conflict. Start with
  those disabled for the offline test. Do not rely on unmodded peers seeing it.
- Asset authorship/redistribution permissions are not documented in the input.
  This private derivative is NOT a cleared public release; see CREDITS.txt.

Removal / rollback
------------------
Equip a vanilla outfit before removing this pack. Close the game, then remove
only assets/mod_overrides/Lawson_Outfit_BeardLib/. Do not remove shared loaders
or other Lawson folders. Restore your backup if necessary.

Rebuild: tools/pd2-port/build_outfit_beardlib.py in Man1nWhite/universal-modder.
BUILD_INFO.json records source hashes and generated payload hashes.
