# Bonnie -> Miranda Lawson (Payday 2 character swap)

Replaces **Bonnie**'s player model with Miranda Lawson. Works in character
select and in-game. Built for Diesel 3.0 (Update 247) — standard mod_overrides.

## Install (Windows 11)

1. SuperBLT required (you have it). BeardLib optional.
2. Extract this zip **into `PAYDAY 2\mods\mod_overrides\`** so the layout is:

   ```
   PAYDAY 2\mods\mod_overrides\lawson_bonnie\
       units/pd2_dlc_bonnie/characters/npc_criminal_bonnie\...
       units\payday2\characters\shared_textures\lawson\...
   ```

3. Test **single player first** -> pick Bonnie -> check menu model + a heist.

## Inside

- `npc_criminal_bonnie.model` / `npc_criminal_bonnie_menu.model` — Lawson mesh on Bonnie's skeleton (animations, ragdolls,
  bone attachments keep working; hands weighted to fingers).
- `mtr_bonnie.material_config` (+ `_cc`) — original materials untouched; 10 dedicated `lawson_*`
  materials added and used only by the Lawson pieces. Vests/bags/armor keep
  their vanilla textures.
- `shared_textures/lawson/*.texture` — Lawson diffuse + normal maps (DXT5).
  The same folder is used by all three Lawson mods, so they co-install cleanly.

## Known limitations (v1)

- Co-op caution: other players' armor-pieces/bags can crash clients with custom
  models (engine issue). SP and bot lobbies are fine.
- Vanilla vest/bag meshes fit Bonnie's body — they may clip slightly.
- If textures look flipped vertically in-game, say so — one flag to fix.

## Remove

Delete the `lawson_bonnie` folder from `mods\mod_overrides\`.
