LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.honoko4 = {
	category = "honoko4",

	unit = "units/honoko4/skins/honoko4/honoko4",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
