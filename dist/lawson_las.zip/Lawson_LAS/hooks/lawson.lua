LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.lawson = {
	category = "lawson",

	unit = "units/lawson/skins/lawson/lawson",
	fps_unit = "units/lawson/skins/lawson/fps_lawson",

    hide_mask = true,

	hide_armor = true,
	replace_all = true,

	fps_hide_armor = true,
	fps_replace_body = true
}
