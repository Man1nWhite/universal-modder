Miranda Lawson VO over Hila Stream

WHAT IT IS
Hila's voice lines, replaced by short Miranda Lawson clips from Mass Effect, one
game file per line: this pack writes 699 files into
soundbanks/streamed/regular_vox/ under Hila's own voice-line ids. The game plays
a line by its id, so the clip answers that line whether it comes from a bark
event, a heist script or a teammate callout - no event table to keep up to date.

REQUIRES
A working copy of PAYDAY 2 with SuperBLT (or any BLT build). Nothing else:
this route is a file replacement, so BeardLib and the XAudio API are not used.

INSTALL
  1. Close PAYDAY 2.
  2. Copy the whole folder "Miranda Lawson VO over Hila Stream" into
       ...\\Steam\\steamapps\\common\\PAYDAY 2\\mods\\
     Final check: PAYDAY 2\\mods\\Miranda Lawson VO over Hila Stream\\main.xml must exist.
     Do not nest it twice (mods\\Miranda Lawson VO over Hila Stream\\Miranda Lawson VO over Hila Stream\\main.xml is wrong).
  3. Start the game and play a heist with Hila (as your heister, or as an AI
     teammate). Her barks are Miranda's now; the heist-scripted story lines she
     speaks as an NPC are not touched - those are not heister voice lines.

UNINSTALL
Delete this folder, or untick it in the main-menu Mods list.

HOW IT REPLACES LINES
Every heister voice line is soundbanks/streamed/regular_vox/<id>.stream - RIFF
IMA ADPCM, 44.1 kHz mono, 64 samples per 36-byte block. Replacing the file under
that id replaces the line, which is how voice packs have always been made.
The clips are cut from the source oggs and encoded to ADPCM (measured 30 dB SNR
against the ogg source, i.e. transparent for speech at this bitrate).

WHAT IS NOT IN HERE
  * 27 of the 885 ids in this pack's table are streamed by the vanilla game as Wwise
    Vorbis, and only the Wwise encoder can write that. Those ids are left out on
    purpose: an ADPCM file under a Vorbis id is not the audio the bank expects.
    This stream pack leaves those lines vanilla; it does not include a Wwise Vorbis encoder.
  * 162 ids answer slots whose best clip scored below semantic fit 8 with no take
    in either source archive (`voice_lines_vox/miranda_lawson/removed_slots.csv`).
    This pack does not write those ids either, so the vanilla Hila line plays there.
  * The `robbers_mission_gen` bank: those ids are heist-scripted NPC lines with
    their own text, not heister barks.

IF NOTHING CHANGES
Check that the folder is in mods/ and not nested, that Hila is the heister you
hear (rb21), and that no other Hila voice pack is installed. A second pack
writing the same ids wins or loses by load order.

CONTENTS
  main.xml                              mod folder marker, nothing to configure
  mod.txt                               BLT mod-list metadata
  soundbanks/streamed/regular_vox/      699 .stream files, 661s of audio in all
  hila_stream_map.csv                   id -> slot -> source clip (build manifest)

Source archives: references/voice/Голос Лоусон.7z and references/voice/LAWSON VOICE (PAYDAY 2).7z
Mapping: voice_lines_vox/miranda_lawson/hila_intent_cuts.csv
Nothing outside this folder is touched: music, radio, other heisters and all
vanilla files stay as they are.
