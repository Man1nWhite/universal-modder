-- OfficeSuite + Miranda Head LAS: no default glove over the outfit's own body, hands or no hands.
-- D58/D60. "Default" gloves must resolve to no glove unit, so what this pack
-- models on the arms is what shows - and this pack models no hands. A glove the
-- player picks by hand still spawns and wins. No bare-forearm adapter: it would
-- put a vanilla skin band at the wrist. See render_own_hands_lua for the rest.
Hooks:PostHook(BlackMarketTweakData, "init", "officesuite_head_OwnHands", function(self)
	local ps = self.player_styles and self.player_styles["las_officesuite_head"]
	if not ps then return end

	-- No glove unit for "Default". BeardLib reads this value, and `false`
	-- means "spawn nothing"; the outfit's own body stays as built.
	ps.default_glove_id = false

	-- The body still replaces the stock hands. This is what makes the outfit's
	-- own body the only thing on the arms: with the stock hands visible there
	-- would be doubles, and on a cut-handed outfit a strip of vanilla skin.
	if ps.third_body_replacement then ps.third_body_replacement.hands = true end
	if ps.body_replacement then ps.body_replacement.hands = true end
end)
