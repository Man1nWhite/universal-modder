LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.christie = {
	category = "christie",

	unit = "units/christie/skins/christie/christie",
	fps_unit = "units/christie/skins/christie/fps_christie",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
