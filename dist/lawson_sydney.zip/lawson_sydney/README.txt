# Sydney -> Miranda Lawson (Payday 2 character swap)

Replaces **Sydney**'s player model with Miranda Lawson. Works in character
select and in-game. Built for Diesel 3.0 (Update 247) — standard mod_overrides.

## Install (Windows 11)

1. SuperBLT required (you have it). BeardLib optional.
2. Extract this zip **into `PAYDAY 2\mods\mod_overrides\`** so the layout is:

   ```
   PAYDAY 2\mods\mod_overrides\lawson_sydney\
       units/pd2_dlc_opera/characters/npc_criminals_fem_3\...
       units\payday2\characters\shared_textures\lawson\...
   ```

3. Test **single player first** -> pick Sydney -> check menu model + a heist.

## Inside

- `npc_criminal_sydney.model` / `npc_criminal_sydney_menu.model` — Lawson mesh on Sydney's skeleton (animations, ragdolls,
  bone attachments keep working; hands weighted to fingers).
- `mtr_criminal_sydney.material_config` (+ `_cc`) — original materials untouched; 10 dedicated `lawson_*`
  materials added and used only by the Lawson pieces. Vests/bags/armor keep
  their vanilla textures.
- `shared_textures/lawson/*.texture` — Lawson diffuse + normal maps (DXT5).
  The same folder is used by all three Lawson mods, so they co-install cleanly.

## Known limitations (v1)

- Co-op caution: other players' armor-pieces/bags can crash clients with custom
  models (engine issue). SP and bot lobbies are fine.
- Vanilla vest/bag meshes fit Sydney's body — they may clip slightly.
- If textures look flipped vertically in-game, say so — one flag to fix.

## Remove

Delete the `lawson_sydney` folder from `mods\mod_overrides\`.
