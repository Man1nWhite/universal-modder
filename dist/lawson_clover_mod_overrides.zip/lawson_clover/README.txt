# Clover → Miranda Lawson (Payday 2 character swap)

Replaces **Clover's** player model with Miranda Lawson. Works in the character
select menu and in-game (heist). Built for Diesel 3.0 (Update 247) — .model
format unchanged, so standard `mod_overrides` loading works.

## Install (Windows 11)

1. You need **SuperBLT** (you already have it — Diesel Crate Browser is a
   SuperBLT mod). BeardLib is optional.
2. Open your Payday 2 install folder, then `mods\mod_overrides\`.
   (No `mod_overrides` folder? Create it inside `mods\`.)
3. Extract this zip **into `mods\mod_overrides\`** so the layout looks like:

   ```
   PAYDAY 2\mods\mod_overrides\lawson_clover\
       units\payday2\characters\npc_criminal_female_1\...
       units\payday2\characters\shared_textures\lawson\...
   ```

   (Any folder name works — `lawson_clover` shown as an example.)
4. Start the game → **single player first** → pick Clover → check the menu
   model and a heist.

## What's inside

| File | What |
|---|---|
| `npc_criminal_female_1.model` / `_menu.model` | Lawson mesh (body/head/hands/hair) on Clover's skeleton — her animations, ragdolls, and bone attachments keep working |
| `mtr_fem1.material_config` / `mtr_fem1_cc.material_config` | The 10 materials Clover uses repointed to Lawson textures (untouched materials still use vanilla game textures — nothing else to install) |
| `shared_textures/lawson/*.texture` | Lawson diffuse + normal maps (DXT5 DDS) |

## Known limitations (v1)

- **Co-op caution**: when another player equips the two-piece armor or carries
  an attachable bag, custom character models can crash clients (a known
  Diesel/BeardLib issue with bone attachments). **SP and bot lobbies are fine.**
  If you co-op a lot, play vanilla lobbies at your own risk or tell me and I'll
  ship a "no-armor-pieces" variant.
- Clover's armor/vest/bag meshes (kept from vanilla) fit Clover's body — they
  may clip slightly on Lawson's proportions. Everything else is Lawson.
- If the textures look flipped vertically in-game, tell me — one flag in the
  DDS build and I'll re-ship (the models are correct either way).

## Remove

Delete the `lawson_clover` folder from `mods\mod_overrides\` — done.
