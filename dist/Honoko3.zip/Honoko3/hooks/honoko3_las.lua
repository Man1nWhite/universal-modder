LegendaryArmours = LegendaryArmours or {}
la = LegendaryArmours

la.honoko3 = {
	category = "honoko3",

	unit = "units/honoko3/skins/honoko3/honoko3",

	hide_mask = true,
	hide_armor = true,
	replace_body = true,
	fps_hide_armor = true,
	fps_replace_body = true
}
