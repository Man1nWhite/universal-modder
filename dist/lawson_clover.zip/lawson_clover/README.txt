# Clover -> Miranda Lawson (PAYDAY 2 character swap)

Packaging revision 1.2. In-game appearance, animation and compatibility have
NOT been verified by this packaging and SkinBones repair. The previous
'works in-game' claim was not supported by an in-game test.

## Requirements

- SuperBLT (legacy BLT alone is not sufficient for BeardLib).
- BeardLib, installed as PAYDAY 2\mods\BeardLib\mod.txt.
  Get it from https://github.com/simon-wh/PAYDAY-2-BeardLib/releases
  BeardLib is REQUIRED: main.xml registers the new Lawson texture paths.
  PocoHUD working confirms Lua mods load, not that model overrides load.

## Install / upgrade

1. Fully exit PAYDAY 2.
2. Move any older lawson_clover folder outside the game as a backup.
   Check mods\, mods\mod_overrides\ and assets\mod_overrides\ for copies.
3. Extract this ZIP into PAYDAY 2\assets\mod_overrides\ (create it if absent).
   The final layout must be exactly:

   PAYDAY 2\assets\mod_overrides\lawson_clover\main.xml
   PAYDAY 2\assets\mod_overrides\lawson_clover\README.txt
   PAYDAY 2\assets\mod_overrides\lawson_clover\units\...

   NOT mods\mod_overrides, and no extra lawson_clover folder level.
   Do not put these asset packs beside PocoHUD in mods\.
4. Initially test just this pack. Temporarily move other replacements for
   Clover outside the game, and select the default outfit/two-piece suit.
5. Restart the game, select Clover, and check the unmasked menu preview.
   Back up your save before testing an offline heist; also inspect a matching
   third-person/team character. This is not a separate outfit to equip.

## If nothing changes

- Confirm main.xml and units are directly inside the folder shown above.
- Confirm BeardLib is installed and enabled and the pack is not disabled in
  BeardLib. Seeing an entry in a mod manager is not proof its assets loaded.
- Fully restart after changing files/settings; merely switching characters
  may leave cached resources in use.
- If still unchanged, share a screenshot of the full install path, the game
  version, SuperBLT/BeardLib versions, and the newest mods\logs\ log (if present).
  For a crash, also share %LOCALAPPDATA%\PAYDAY 2\crash.txt, if present.

## Contents and limitations

- Rebuilt menu and third-person .model files and two .material_config files.
- Nineteen diffuse/normal .texture files; main.xml registers their new DB paths.
- Repaired SkinBones bone-palette mappings in .model files (local 0..N-1
  indices into SkinBones.object_ids instead of Object3D section IDs) to fix
  native skinning out-of-bounds crashes; geometry, weights and textures are
  unchanged.
- Custom outfits may use different models; vanilla armor/bags may clip.
- First-person arms, facial animation, masks, ragdolls and co-op compatibility
  are not verified. Test offline first; do not assume multiplayer safety.

## Remove

With the game closed, move lawson_clover out of assets\mod_overrides\.
