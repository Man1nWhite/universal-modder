Miranda Lawson VO over Hila

WHAT IT IS
Replaces Hila's heister barks (voice switch "rb21") with 78 short Miranda Lawson
clips from Mass Effect, mapped by intent onto 887 PD2 voice-line ids.

REQUIRES (both are hard requirements, the pack is silent without them)
  * SuperBLT with the built-in XAudio API  - https://modworkshop.net/mod/58342
  * BeardLib 5.x                           - https://modworkshop.net/mod/14924
BeardLib's Sounds module aborts with "Sounds module requires the XAudio API!"
on plain BLT/BLT4, so SuperBLT really is needed.

INSTALL
  1. Close PAYDAY 2.
  2. Copy the whole folder "Miranda Lawson VO over Hila" into
       ...\Steam\steamapps\common\PAYDAY 2\mods\
     Final check: PAYDAY 2\mods\Miranda Lawson VO over Hila\main.xml must exist.
     Do not nest it twice (mods\Miranda Lawson VO over Hila\Miranda Lawson VO over Hila\main.xml is wrong).
  3. Start the game. Main menu -> Mods: this pack and BeardLib are both listed.
     Nothing needs to be toggled - BeardLib picks the pack up from main.xml.
  4. Play a heist with Hila (as your heister, or as an AI teammate).

UNINSTALL
Delete this folder, or untick the pack in the main-menu Mods list.
Only one Hila voice pack should be installed at a time - two packs claiming the
same (id, prefix) pair means the one that loads later wins.

IF YOU HEAR NO CHANGE
Enable BeardLib's "Log Sounds" option (Mods -> BeardLib options), play once, then
open the newest payday2_win32_release_*.log and read the
"Incoming sound check: ID ... Prefixes ..." lines. Hila's own barks carry the
prefix rb21. This build is keyed on PD2's numeric voice-line ids; if the log shows
bark event names (g18, f11e_plu, f30x_any, ...) instead, the pack needs re-keying -
see docs/pd2-voice-mod-install.md in the source repository.

CONTENTS
  main.xml                             BeardLib Sounds module config (prefix rb21)
  sounds/                              78 ogg clips, peak-matched to -1.5 dBFS
  slot_to_ogg.csv, hila_slot_pieces.csv  build manifest (not read by the game)

Source archive: references/Голос Лоусон.7z
Mapping: voice_lines_vox/miranda_lawson/hila_intent_cuts.csv
Nothing outside this folder is touched: music, radio, other heisters and all
vanilla files stay as they are.
