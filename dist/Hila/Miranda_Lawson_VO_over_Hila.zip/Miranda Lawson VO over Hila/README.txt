Miranda Lawson VO over Hila

Requires SuperBLT + BeardLib. Extract the 'Miranda Lawson VO over Hila' folder into
PAYDAY 2/mods/  (or assets/mod_overrides/ if BeardLib loads overrides).

Replaces Hila's heister barks (voice prefix rb21) with 78 short
Miranda Lawson clips from Mass Effect, mapped by intent onto 887 PD2 sound IDs.

Source archive: references/Голос Лоусон.7z
Mapping: voice_lines_vox/miranda_lawson/hila_intent_cuts.csv

Does not replace music, radio, or other heisters. Remove the folder to uninstall.
